import { test, expect } from '@playwright/test';
import http from 'node:http';

const PORT = 49883;
function pageHtml(variant) {
  const title = variant === 'b' ? 'Run Diff Demo - updated' : 'Run Diff Demo';
  return `<!doctype html><html><body><h1>${title}</h1><input id="name"/><button id="load">Load</button>${variant === 'b' ? '<button id="extra">Extra</button>' : ''}<div id="out">idle</div>
<script>document.getElementById('load').addEventListener('click', async () => { const r = await fetch('/api/data'); const j = await r.json(); document.getElementById('out').textContent = 'loaded:' + (j.value ?? j.error); });
const ex = document.getElementById('extra'); if (ex) ex.addEventListener('click', () => { document.getElementById('out').textContent = 'x'; });
${variant === 'b' ? "console.error('demo page error in candidate');" : ''}</script></body></html>`;
}
let server;
test.beforeAll(async () => {
  const variant = process.env.FIXTURE_VARIANT ?? 'a';
  server = http.createServer((req, res) => {
    if (req.url === '/') { res.setHeader('content-type', 'text/html'); res.end(pageHtml(variant)); }
    else if (req.url === '/api/data') { res.setHeader('content-type', 'application/json'); if (variant === 'b') { res.statusCode = 500; res.end('{"error":"boom"}'); } else res.end('{"value":42}'); }
    else { res.statusCode = 404; res.end(); }
  }).listen(PORT, '127.0.0.1');
});
test.afterAll(() => server.close());
test.use({ trace: 'on', browserName: process.env.FIXTURE_BROWSER ?? 'chromium' });
test('demo flow', async ({ page }) => {
  await page.goto('http://127.0.0.1:' + PORT + '/');
  await test.step('fill name', async () => { await page.fill('#name', 'run-diff'); });
  await page.click('#load');
  await expect(page.locator('#out')).toContainText('loaded:');
  if ((process.env.FIXTURE_VARIANT ?? 'a') === 'b') await page.click('#extra');
});

// Deliberately expected-fail test: its trace records failed assertion steps.
test('failing check', async ({ page }) => {
  test.fail();
  await page.goto('http://127.0.0.1:' + PORT + '/');
  await expect(page.locator('#does-not-exist')).toBeVisible({ timeout: 1000 });
});
